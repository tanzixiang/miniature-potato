// pages/register/register.js
Page({
  data: {
    username: '',
    password: '',
    confirmPassword: ''
  },
  bindUsernameInput: function(e) {
    this.setData({
      username: e.detail.value
    });
  },
  bindPasswordInput: function(e) {
    this.setData({
      password: e.detail.value
    });
  },
  bindConfirmPasswordInput: function(e) {
    this.setData({
      confirmPassword: e.detail.value
    });
  },
  register: function() {
    if (this.data.password !== this.data.confirmPassword) {
      wx.showToast({
         title: '两次输入的密码不一致',
         icon: 'none'
      })
      return;
    }
    console.log(`Register with username: ${this.data.username}, password: ${this.data.password}`);
    // 这里可以添加注册逻辑，如发送请求到服务器注册新用户
  }
});