// pages/success/success.js
Page({
  goHome: function() {
    wx.redirectTo({
     url: '/pages/index/index' // 替换为你的主页路径
   });
  }
});
