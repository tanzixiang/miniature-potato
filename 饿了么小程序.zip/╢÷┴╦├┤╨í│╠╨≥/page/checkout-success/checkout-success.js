// pages/checkout-success/checkout-success.js
Page({
  onGoHome: function() {
    // 跳转到首页
    wx.redirectTo({
      url: '/pages/home/home' // 确保这是你的首页路径
    });
  }
});