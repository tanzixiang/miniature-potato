// pages/checkout/checkout.js
Page({
  data: {
    cartItems: [], // 假设从全局变量或页面参数获取
    totalAmount: 0
  },
  onLoad: function(options) {
    // 初始化页面时获取购物车数据
    const cartItems = wx.getStorageSync('cartItems');
    this.setData({
      cartItems: cartItems,
      totalAmount: this.calculateTotal(cartItems)
    });
  },
  calculateTotal: function(cartItems) {
    return cartItems.reduce((total, item) => total + item.price * item.quantity, 0);
  },
  increaseQuantity: function(e) {
    const id = e.currentTarget.dataset.id;
    const cartItems = this.data.cartItems.map(item => {
      if (item.id === id) {
        return { ...item, quantity: item.quantity + 1 };
      }
      return item;
    });
    this.setData({
      cartItems: cartItems,
      totalAmount: this.calculateTotal(cartItems)
    });
  },
  decreaseQuantity: function(e) {
    const id = e.currentTarget.dataset.id;
    const cartItems = this.data.cartItems.map(item => {
      if (item.id === id && item.quantity > 1) {
        return { ...item, quantity: item.quantity - 1 };
      }
      return item;
    });
    this.setData({
      cartItems: cartItems,
      totalAmount: this.calculateTotal(cartItems)
    });
  },
  onCheckout: function() {
    // 跳转到支付页面或其他结算流程
    wx.navigateTo({
       url: '/pages/pay/pay'
     });
  }
});