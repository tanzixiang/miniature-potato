// pages/order_status/order_status.js
Page({
  data: {
    order: {
      orderId: '202112345',
      status: '骑手派送中',
      items: [
        { id: '1', name: '金针菇', pic: '/path/to/image1.jpg', price: 3, quantity: 1 },
      ],
      totalAmount: 3
    }
  },
  onLoad: function(options) {
    // 这里可以添加从服务器获取订单数据的逻辑
    // 假设订单数据已经通过页面参数传递
    const orderId = options.orderId;
    // 模拟获取订单数据
    wx.cloud.callFunction({
     name: 'getOrderDetails',
     data: { orderId },
     success: res => {
       this.setData({
         order: res.result
       });
     }
   });
  }
});