// pages/login/login.js
Page({
  data: {
    username: '',
    password: ''
  },
  bindUsernameInput: function(e) {
    this.setData({
      username: e.detail.value
    });
  },
  bindPasswordInput: function(e) {
    this.setData({
      password: e.detail.value
    });
  },
  login: function() {
    console.log(`Login with username: ${this.data.username}, password: ${this.data.password}`);
    // 这里可以添加登录逻辑，如发送请求到服务器验证用户信息
  }
});